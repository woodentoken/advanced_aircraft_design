"""OpenMDAO System to compute drag based on the methods in FLOPS AERO."""

import numpy as np
import openmdao.api as om

from aviary.subsystems.aerodynamics.aero_common import DynamicPressure
from aviary.subsystems.aerodynamics.flops_based.buffet_lift import BuffetLift
from aviary.subsystems.aerodynamics.flops_based.compressibility_drag import CompressibilityDrag
from aviary.subsystems.aerodynamics.flops_based.drag import TotalDrag
from aviary.subsystems.aerodynamics.flops_based.mux_component import MuxComponent
from aviary.subsystems.aerodynamics.flops_based.skin_friction import SkinFriction
from aviary.subsystems.aerodynamics.flops_based.skin_friction_drag import SkinFrictionDrag
from aviary.subsystems.ExternalAero.ovl_based.ovl_lift import OVLLift
from aviary.subsystems.ExternalAero.ovl_based.ovl_induced_drag import OVLInducedDrag
from aviary.subsystems.ExternalAero.ovl_based.ovl_pressure_drag import OVLPressureDrag
from aviary.subsystems.ExternalAero.ovl_based.ovl_compress_drag import OVLCompressDrag

from aviary.variable_info.variables import Aircraft, Dynamic, Mission


class ExternalAeroGroup(om.Group):
    """FLOPS-based computed external aero group."""

    def initialize(self):
        self.options.declare(
            'num_nodes', default=1, types=int, desc='Number of nodes along mission segment'
        )
        self.options.declare('gamma', default=1.4, desc='Ratio of specific heats for air.')

    def setup(self):
        num_nodes = self.options['num_nodes']
        gamma = self.options['gamma']

        comp = MuxComponent()
        self.add_subsystem(
            'Mux',
            comp,
            promotes_inputs=['aircraft:*'],
            promotes_outputs=[
                'wetted_areas',
                'fineness_ratios',
                'characteristic_lengths',
                'laminar_fractions_upper',
                'laminar_fractions_lower',
            ],
        )

        self.add_subsystem(
            'DynamicPressure',
            DynamicPressure(num_nodes=num_nodes, gamma=gamma),
            promotes_inputs=[
                Dynamic.Atmosphere.MACH,
                Dynamic.Atmosphere.STATIC_PRESSURE,
            ],
            promotes_outputs=[Dynamic.Atmosphere.DYNAMIC_PRESSURE],
        )

        comp = OVLLift(num_nodes=num_nodes)
        self.add_subsystem(
            name=Dynamic.Vehicle.LIFT,
            subsys=comp,
            promotes_inputs=[
                Aircraft.Wing.AREA,
                Aircraft.Wing.ASPECT_RATIO,
                Aircraft.Wing.CHORD_PER_SEMISPAN_DIST,
                Aircraft.Wing.DIHEDRAL,
                Aircraft.Wing.HEIGHT,
                Aircraft.Wing.SPAN,
                Aircraft.Wing.SWEEP,
                Aircraft.Wing.TAPER_RATIO,
                Aircraft.Wing.THICKNESS_TO_CHORD_ROOT,
                Aircraft.Wing.THICKNESS_TO_CHORD_TIP,
                Aircraft.Wing.MAX_CAMBER_AT_70_SEMISPAN,
                
                Aircraft.VerticalTail.AREA,
                Aircraft.VerticalTail.ASPECT_RATIO,
                Aircraft.VerticalTail.SWEEP,
                Aircraft.VerticalTail.TAPER_RATIO,
                Aircraft.VerticalTail.THICKNESS_TO_CHORD,
                
                Aircraft.HorizontalTail.AREA,
                Aircraft.HorizontalTail.ASPECT_RATIO,
                Aircraft.HorizontalTail.SWEEP,
                Aircraft.HorizontalTail.TAPER_RATIO,
                Aircraft.HorizontalTail.THICKNESS_TO_CHORD,
                
                Aircraft.Fuselage.LENGTH,
                Aircraft.Fuselage.MAX_HEIGHT,
                Aircraft.Fuselage.MAX_WIDTH,
                
                # Aircraft Flow Conditions
                Dynamic.Atmosphere.MACH,
                Dynamic.Vehicle.ANGLE_OF_ATTACK,
            ],
            promotes_outputs=['cl', Dynamic.Vehicle.LIFT],
        )

        comp = OVLPressureDrag(num_nodes=num_nodes, gamma=gamma)
        self.add_subsystem(
            'PressureDrag',
            comp,
            promotes_inputs=[
                Aircraft.Wing.AREA,
                Aircraft.Wing.ASPECT_RATIO,
                Aircraft.Wing.CHORD_PER_SEMISPAN_DIST,
                Aircraft.Wing.DIHEDRAL,
                Aircraft.Wing.HEIGHT,
                Aircraft.Wing.SPAN,
                Aircraft.Wing.SWEEP,
                Aircraft.Wing.TAPER_RATIO,
                Aircraft.Wing.THICKNESS_TO_CHORD_ROOT,
                Aircraft.Wing.THICKNESS_TO_CHORD_TIP,
                Aircraft.Wing.MAX_CAMBER_AT_70_SEMISPAN,
                
                Aircraft.VerticalTail.AREA,
                Aircraft.VerticalTail.ASPECT_RATIO,
                Aircraft.VerticalTail.SWEEP,
                Aircraft.VerticalTail.TAPER_RATIO,
                Aircraft.VerticalTail.THICKNESS_TO_CHORD,
                
                Aircraft.HorizontalTail.AREA,
                Aircraft.HorizontalTail.ASPECT_RATIO,
                Aircraft.HorizontalTail.SWEEP,
                Aircraft.HorizontalTail.TAPER_RATIO,
                Aircraft.HorizontalTail.THICKNESS_TO_CHORD,
                
                Aircraft.Fuselage.LENGTH,
                Aircraft.Fuselage.MAX_HEIGHT,
                Aircraft.Fuselage.MAX_WIDTH,
                
                # Aircraft Flow Conditions
                Dynamic.Atmosphere.MACH,
                Dynamic.Vehicle.ANGLE_OF_ATTACK,
            ],
        )

        comp = OVLInducedDrag(num_nodes=num_nodes, gamma=gamma)
        self.add_subsystem(
            'InducedDrag',
            comp,
            promotes_inputs=[
                Aircraft.Wing.AREA,
                Aircraft.Wing.ASPECT_RATIO,
                Aircraft.Wing.CHORD_PER_SEMISPAN_DIST,
                Aircraft.Wing.DIHEDRAL,
                Aircraft.Wing.HEIGHT,
                Aircraft.Wing.SPAN,
                Aircraft.Wing.SWEEP,
                Aircraft.Wing.TAPER_RATIO,
                Aircraft.Wing.THICKNESS_TO_CHORD_ROOT,
                Aircraft.Wing.THICKNESS_TO_CHORD_TIP,
                Aircraft.Wing.MAX_CAMBER_AT_70_SEMISPAN,
                
                Aircraft.VerticalTail.AREA,
                Aircraft.VerticalTail.ASPECT_RATIO,
                Aircraft.VerticalTail.SWEEP,
                Aircraft.VerticalTail.TAPER_RATIO,
                Aircraft.VerticalTail.THICKNESS_TO_CHORD,
                
                Aircraft.HorizontalTail.AREA,
                Aircraft.HorizontalTail.ASPECT_RATIO,
                Aircraft.HorizontalTail.SWEEP,
                Aircraft.HorizontalTail.TAPER_RATIO,
                Aircraft.HorizontalTail.THICKNESS_TO_CHORD,
                
                Aircraft.Fuselage.LENGTH,
                Aircraft.Fuselage.MAX_HEIGHT,
                Aircraft.Fuselage.MAX_WIDTH,
                
                # Aircraft Flow Conditions
                Dynamic.Atmosphere.MACH,
                Dynamic.Vehicle.ANGLE_OF_ATTACK,
            ],
        )

        comp = OVLCompressDrag(num_nodes=num_nodes)
        self.add_subsystem(
            'CompressibilityDrag',
            comp,
            promotes_inputs=[
                Aircraft.Wing.AREA,
                Aircraft.Wing.ASPECT_RATIO,
                Aircraft.Wing.CHORD_PER_SEMISPAN_DIST,
                Aircraft.Wing.DIHEDRAL,
                Aircraft.Wing.HEIGHT,
                Aircraft.Wing.SPAN,
                Aircraft.Wing.SWEEP,
                Aircraft.Wing.TAPER_RATIO,
                Aircraft.Wing.THICKNESS_TO_CHORD_ROOT,
                Aircraft.Wing.THICKNESS_TO_CHORD_TIP,
                Aircraft.Wing.MAX_CAMBER_AT_70_SEMISPAN,
                
                Aircraft.VerticalTail.AREA,
                Aircraft.VerticalTail.ASPECT_RATIO,
                Aircraft.VerticalTail.SWEEP,
                Aircraft.VerticalTail.TAPER_RATIO,
                Aircraft.VerticalTail.THICKNESS_TO_CHORD,
                
                Aircraft.HorizontalTail.AREA,
                Aircraft.HorizontalTail.ASPECT_RATIO,
                Aircraft.HorizontalTail.SWEEP,
                Aircraft.HorizontalTail.TAPER_RATIO,
                Aircraft.HorizontalTail.THICKNESS_TO_CHORD,
                
                Aircraft.Fuselage.LENGTH,
                Aircraft.Fuselage.MAX_HEIGHT,
                Aircraft.Fuselage.MAX_WIDTH,
                
                # Aircraft Flow Conditions
                Dynamic.Atmosphere.MACH,
                Dynamic.Vehicle.ANGLE_OF_ATTACK,
            ],
        )

        comp = SkinFriction(num_nodes=num_nodes)
        self.add_subsystem(
            'SkinFrictionCoef',
            comp,
            promotes_inputs=[
                Dynamic.Atmosphere.MACH,
                Dynamic.Atmosphere.STATIC_PRESSURE,
                Dynamic.Atmosphere.TEMPERATURE,
                'characteristic_lengths',
            ],
            promotes_outputs=['skin_friction_coeff', 'Re'],
        )

        comp = SkinFrictionDrag(num_nodes=num_nodes)
        self.add_subsystem(
            'SkinFrictionDrag',
            comp,
            promotes_inputs=[
                'skin_friction_coeff',
                'Re',
                'fineness_ratios',
                'wetted_areas',
                'laminar_fractions_upper',
                'laminar_fractions_lower',
                Aircraft.Wing.AREA,
            ],
        )

        comp = ComputedDrag(num_nodes=num_nodes)
        self.add_subsystem(
            'Drag',
            comp,
            promotes_inputs=[
                Dynamic.Atmosphere.DYNAMIC_PRESSURE,
                Dynamic.Atmosphere.MACH,
                Aircraft.Wing.AREA,
                Aircraft.Design.ZERO_LIFT_DRAG_COEFF_FACTOR,
                Aircraft.Design.LIFT_DEPENDENT_DRAG_COEFF_FACTOR,
                Aircraft.Design.SUBSONIC_DRAG_COEFF_FACTOR,
                Aircraft.Design.SUPERSONIC_DRAG_COEFF_FACTOR,
            ],
            promotes_outputs=['CDI', 'CD0', 'CD', Dynamic.Vehicle.DRAG],
        )

        buf = BuffetLift(num_nodes=num_nodes)
        self.add_subsystem(
            'Buffet',
            buf,
            promotes_inputs=[
                Dynamic.Atmosphere.MACH,
                Mission.Design.MACH,
                Aircraft.Wing.ASPECT_RATIO,
                Aircraft.Wing.MAX_CAMBER_AT_70_SEMISPAN,
                Aircraft.Wing.SWEEP,
                Aircraft.Wing.THICKNESS_TO_CHORD,
            ],
        )

        self.connect('PressureDrag.CD', 'Drag.pressure_drag_coeff')
        self.connect('InducedDrag.induced_drag_coeff', 'Drag.induced_drag_coeff')
        self.connect('CompressibilityDrag.compress_drag_coeff', 'Drag.compress_drag_coeff')
        self.connect('SkinFrictionDrag.skin_friction_drag_coeff', 'Drag.skin_friction_drag_coeff')


class ComputedDrag(om.Group):
    """FLOPS-based computed drag group."""

    def initialize(self):
        self.options.declare('num_nodes', types=int)

    def setup(self):
        nn = self.options['num_nodes']

        self._setup_drag_coeff(
            'CDI',
            input0='pressure_drag_coeff',
            input1='induced_drag_coeff',
            output='CDI',
            desc='lift-dependent drag coefficient,'
            ' including contributions from pressure drag coefficient',
        )

        self._setup_drag_coeff(
            'CD0',
            input0='skin_friction_drag_coeff',
            input1='compress_drag_coeff',
            output='CD0',
            desc='zero-lift drag coefficient',
        )

        self.add_subsystem(
            Dynamic.Vehicle.DRAG,
            TotalDrag(num_nodes=nn),
            promotes_inputs=[
                Aircraft.Design.ZERO_LIFT_DRAG_COEFF_FACTOR,
                Aircraft.Design.LIFT_DEPENDENT_DRAG_COEFF_FACTOR,
                Aircraft.Wing.AREA,
                Aircraft.Design.SUBSONIC_DRAG_COEFF_FACTOR,
                Aircraft.Design.SUPERSONIC_DRAG_COEFF_FACTOR,
                'CDI',
                'CD0',
                Dynamic.Atmosphere.MACH,
                Dynamic.Atmosphere.DYNAMIC_PRESSURE,
            ],
            promotes_outputs=['CD', Dynamic.Vehicle.DRAG],
        )

        self.set_input_defaults(Aircraft.Wing.AREA, 1.0, 'ft**2')

    def _setup_drag_coeff(self, name, input0, input1, output, desc=None):
        nn = self.options['num_nodes']

        input_args = {'val': np.ones(nn), 'units': 'unitless'}
        output_args = dict(input_args)

        if desc is not None:
            output_args['desc'] = desc

        kwargs = {input0: input_args, input1: input_args, output: output_args}

        subsys = self.add_subsystem(
            name,
            om.ExecComp(f'{output} = {input0} + {input1}', **kwargs),
            promotes_inputs=[input0, input1],
            promotes_outputs=[output],
        )
        subsys.declare_coloring(show_summary=False)
